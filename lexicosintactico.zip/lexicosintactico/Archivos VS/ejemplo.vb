 
Imports System

Module Module1
Sub Main()  
DIM  RES1,C,B,A AS INTEGER
DIM  RES2,DIR,NOM,APE AS STRING
  
RES1=A+B+C 
RES2=APE+NOM+DIR 

Console.WriteLine( "EL RESULTADO DE LA SUMA ES " ) 

Console.WriteLine( RES1 ) 

Console.WriteLine( "EL RESULTADO DE LA CONCATENACIÓN ES " ) 

Console.WriteLine( RES2 ) 

