REM Ing. Javier Mendoza Loor 
REM DosNumeros  
DIM  resultado,segundo,primero AS DOUBLE
DIM  verifica AS INTEGER
  

PRINT  "  Programa que calcula Divisiones  " 

WHILE verifica<2

INPUT  "Dame el primer numero: ",primero

INPUT  "Dame el segundo numero: ",segundo
resultado=primero/segundo 

IF primero=0 THEN
verifica=verifica+1 

IF segundo=0 THEN
verifica=verifica+1 

PRINT  "No puedo dividir entre 0" 

END IF 

END IF 

IF segundo>0 THEN

PRINT  "El Resultado es: ",resultado 

END IF 

IF segundo<0 THEN

PRINT  "El Resultado es: ",resultado 

END IF 

IF segundo=0 THEN

PRINT  "No puedo dividir entre 0" 

END IF 

PRINT  " Ya acabe" 

WEND 

